@echo off
REM ================================
REM Install-Customballer-Gunsmith.cmd
REM ================================

REM Pfad zum PowerShell-Skript
set "PS_SCRIPT=%~dp0script\install.ps1"

REM Prüfen, ob das Skript blockiert ist, und ggf. entblocken
powershell -NoProfile -ExecutionPolicy Bypass -Command "if ((Get-Item '%PS_SCRIPT%').Attributes -band [System.IO.FileAttributes]::Blocked) { Unblock-File -Path '%PS_SCRIPT%' }"

REM Skript mit Bypass Execution Policy ausführen
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%"

REM Datei selbst löschen (startet einen verzögerten CMD-Prozess)
cmd /c ping 127.0.0.1 -n 2 >nul & del "%~f0"
