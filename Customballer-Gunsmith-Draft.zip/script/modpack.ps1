﻿# === Basis-Hauptverzeichnis ermitteln ===
if ($MyInvocation.MyCommand.CommandType -eq "ExternalScript") {
    # wenn als PS1 gestartet
    $scriptDir = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
} else {
    # wenn als EXE gestartet
    $scriptDir = Split-Path -Parent (Split-Path -Parent ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName))
}

# Eingabeaufforderung anzeigen
Write-Host "Choose a name for your Customballer Mod Pack: " -ForegroundColor Cyan

# Eingabe vom Benutzer lesen
while ($true) {
    $customname = Read-Host

    # Prüfen, ob Eingabe leer ist
    if ([string]::IsNullOrWhiteSpace($customname)) {
        Write-Host "❌ Please enter a name." -ForegroundColor Red
        continue
    }

    # Prüfen, ob Länge <= 20 ist
    if ($customname.Length -gt 20) {
        Write-Host "❌ The name may contain a maximum of 20 characters." -ForegroundColor Red
        continue
    }

    # Prüfen, ob nur erlaubte Zeichen enthalten sind (A-Z, a-z, ä, ö, ü, -, _)
    if ($customname -notmatch '^[A-Za-zäöüÄÖÜ0-9\-_ ]+$') {
        Write-Host "❌ Only (A-Z, a-z, ä, ö, ü), 0 - 9, '-', ' ' and '_' are allowed." -ForegroundColor Red
        continue
    }

    break
}

Write-Host "✅ Name accepted: $customname" -ForegroundColor Green


# === Ordner-Struktur bauen ===
$customnameUnderline = $customname -replace '\s','_'
$customnameNoSpaces = $customname -replace '\s',''

$modsDir   = Join-Path $scriptDir "Mod-Packs"
if (-not (Test-Path $modsDir)) { New-Item -ItemType Directory -Path $modsDir | Out-Null }

$baseFolder = Join-Path $modsDir ("{0}_CBG_NOMAECK" -f $customnameUnderline)
if (-not (Test-Path $baseFolder)) { New-Item -ItemType Directory -Path $baseFolder | Out-Null }

# === Manifest erstellen (Grundgerüst) ===
$manifestPath = Join-Path $baseFolder "manifest.json"
Set-Content -Path $manifestPath -Value @"
{
 	"`$schema": "https://raw.githubusercontent.com/atampy25/simple-mod-framework/main/Mod%20Manager/src/lib/manifest-schema.json",	
	"id": "${customnameNoSpaces}.CBG_NOMAECK",
	"name": "${customnameUnderline}_CBG_NOMAECK",
	"description": "User self created Customballer Mod-Pack created with NOMAECK's Customballer Gunsmith",
	"authors": ["NOMAECK"],
	"frameworkVersion": "2.33.27",
	"version": "1.0.0",
	"blobsFolders": ["blobs"],
	"thumbs": ["ConsoleCmd OnlineResources_Disable 1"],
	"options": [
"@


 #Project.json erstellen
    Set-Content -Path (Join-Path $baseFolder "project.json") -Value @"
{
    "customPaths": []
}
"@

# === Dateien kopieren ===
$customModsPath = Join-Path $scriptDir "Customballer-Mods"
$tempRoot = Join-Path $scriptDir "mod-packs\temp"
$excludedNames = @('manifest.json','project.json') | ForEach-Object { $_.ToLower() }
$imports = @()

# Temp-Verzeichnis neu anlegen
if (Test-Path $tempRoot) { Remove-Item $tempRoot -Recurse -Force }
New-Item -Path $tempRoot -ItemType Directory | Out-Null

if (Test-Path $customModsPath) {
    $zipFiles = Get-ChildItem -Path $customModsPath -Filter *.zip -File
    foreach ($zip in $zipFiles) {
        Write-Host "📦 unzip $($zip.Name)..." -ForegroundColor Cyan

        $extractDest = Join-Path $tempRoot ([IO.Path]::GetFileNameWithoutExtension($zip.Name))
        Expand-Archive -Path $zip.FullName -DestinationPath $extractDest -Force

        # === Struktur: EntpackterHauptordner\Hauptordner\Unterordner
        $hauptordner = Get-ChildItem -Path $extractDest -Directory | Select-Object -First 1
        $unterordnerList = Get-ChildItem -Path $hauptordner.FullName -Directory

        foreach ($unter in $unterordnerList) {
            $targetBase = Join-Path $baseFolder $unter.Name
            Write-Host "→ copy '$($unter.FullName)' → '$targetBase'" -ForegroundColor Gray

            # Zielordner erstellen (falls nicht vorhanden)
            if (-not (Test-Path $targetBase)) {
                New-Item -Path $targetBase -ItemType Directory -Force | Out-Null
            }

            # Dateien und Ordner kopieren, bestimmte Dateien überspringen
            Get-ChildItem -Path $unter.FullName -Recurse -Force | ForEach-Object {
                if ($_.PSIsContainer) {
                    $rel = $_.FullName.Substring($unter.FullName.Length).TrimStart('\','/')
                    $dest = Join-Path $targetBase $rel
                    if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest -Force | Out-Null }
                } else {
                    if ($excludedNames -notcontains $_.Name.ToLower()) {
                        $rel = $_.FullName.Substring($unter.FullName.Length).TrimStart('\','/')
                        $dest = Join-Path $targetBase $rel
                        Copy-Item $_.FullName $dest -Force
                    }
                }
            }
        }

        # === Manifest-Import-Datei prüfen
        $manifestImportFile = Join-Path $hauptordner.FullName "manifestimport.txt"
        if (Test-Path $manifestImportFile) {
            $importContent = Get-Content $manifestImportFile -Raw
            $imports += ,$importContent
        }

        # Entpackten Inhalt entfernen
        Remove-Item -Path $extractDest -Recurse -Force
    }
} else {
    Write-Host "⚠️ No 'Customballer-Mods'-folder found: $customModsPath" -ForegroundColor Yellow
}



# === Alle Manifeste importieren ===
if ($imports.Count -gt 0) {
    # Alle Inhalte mit Komma getrennt in das Manifest einfügen
    $joinedImports = ($imports -join ",`n")
    Add-Content -Path $manifestPath -Value $joinedImports
}

# Manifest schließen
Add-Content -Path $manifestPath -Value @"
        ]
}
"@

# === ZIP erstellen ===
$zipPath = Join-Path $modsDir ("{0}_CBG_NOMAECK.zip" -f $customnameUnderline)
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path $baseFolder -DestinationPath $zipPath

# === Ordner nach dem Packen löschen ===
if (Test-Path $baseFolder) {
   Remove-Item $baseFolder -Recurse -Force
}

# === Ordner im Explorer öffnen ===
$zipFolder = Split-Path $zipPath -Parent

$shell = New-Object -ComObject Shell.Application
$alreadyOpen = $false
foreach ($window in $shell.Windows()) {
    try {
        if ($window.FullName -like "*explorer.exe" -and 
            $window.Document.Folder.Self.Path -eq $zipFolder) {
            $alreadyOpen = $true
            break
        }
    } catch {}
}
if (-not $alreadyOpen) {
    Start-Process explorer.exe -ArgumentList $zipFolder
}
