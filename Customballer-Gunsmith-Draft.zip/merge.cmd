@echo off
set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%script\modpack.ps1"
start "" powershell -ExecutionPolicy Bypass -NoProfile -File "%PS_SCRIPT%"
exit /b